# python-climb-mobile-information
python深度嵌套爬取手机信息
爬虫项目简介请查看博客： 
https://blog.csdn.net/qq_44079295/article/details/94315815

记得修改import的目录以及创建好相应的param.py中的手机存储目录参数
