data_path = r'C:/Users/陈汉武/Desktop/mobile/mobile_type.csv'  #存放各种手机类型的文件，起始文件
mobile_data_path = r'C:/Users/陈汉武/Desktop/mobile/mobile_data'  #存放各种手机url以及简单参数的目录
evaluate_data_path=r'C:/Users/陈汉武/Desktop/mobile/mobile_evaluate'  #存放评论的目录
param_data_path=r'C:/Users/陈汉武/Desktop/mobile/mobile_param'   #存放参数的目录
header = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
 }