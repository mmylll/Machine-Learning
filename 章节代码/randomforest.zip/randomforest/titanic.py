# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 15:38:43 2019

@author: admin
"""

import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#import warningswarnings.filterwarnings('ignore')%matplotlib inline

train_df=pd.read_csv("train.csv")
train_df.head()
def missingdata(data):    
    total = data.isnull().sum().sort_values(ascending = False)    
    percent = (data.isnull().sum()/data.isnull().count()*100).sort_values(ascending = False)    
    ms=pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])    
    ms= ms[ms["Percent"] > 0]    
    f,ax =plt.subplots(figsize=(8,6))    
    plt.xticks(rotation='90')    
    fig=sns.barplot(ms.index, ms["Percent"],color="green",alpha=0.8)    
    plt.xlabel('Features', fontsize=15)    
    plt.ylabel('Percent of missing values', fontsize=15)    
    plt.title('Percent missing data by feature', fontsize=15)    
    return ms

missingdata(train_df)
train_df['Embarked'].fillna(train_df['Embarked'].mode()[0], inplace = True)
train_df['Age'].fillna(train_df['Age'].median(), inplace = True)

drop_column = ['Cabin']
train_df.drop(drop_column, axis=1, inplace = True)

print('check the nan value in train data')
print(train_df.isnull().sum())

all_data = train_df
x = all_data[['Age','Fare']]
y = all_data['Survived']
# for dataset in all_data :
#     dataset['FamilySize'] = dataset.apply(lambda x: x['SibSp'] + x['Parch'] + 1, axis=1)
dataset = all_data
dataset['FamilySize'] = dataset.apply(lambda x: x['SibSp'] + x['Parch'] + 1, axis=1)
import re# Define function to extract titles from passenger names
def get_title(name):
    title_search = re.search(' ([A-Za-z]+)\.', name)    
    # If the title exists, extract and return it.    
    if title_search:
        return title_search.group(1)    
    return ""
    # Create a new feature Title, containing the titles of passenger namesfor dataset in all_data:    
dataset['Title'] = dataset['Name'].apply(get_title)# Group all non-common titles into one single grouping "Rare"for dataset in all_data:    dataset['Title'] = dataset['Title'].replace(['Lady', 'Countess','Capt', 'Col','Don',                                                  'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')
dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')    
dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')    
dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')
dataset['Age_bin'] = pd.cut(dataset['Age'], bins=[0,14,20,40,120],labels=['Children','Teenage','Adult','Elder'])
dataset['Fare_bin']=pd.cut(dataset['Fare'], bins=[0,7.91,14.45,31,120],labels=['Low_fare','median_fare','Average_fare','high_fare'])
# for dataset in all_data:    
#     dataset['Age_bin'] = pd.cut(dataset['Age'], bins=[0,14,20,40,120],labels=['Children','Teenage','Adult','Elder'])
# for dataset in all_data:    
#     dataset['Fare_bin']=pd.cut(dataset['Fare'], bins=[0,7.91,14.45,31,120],labels=['Low_fare','median_fare','Average_fare','high_fare'])                                                                                
# traindf=train_df
# for dataset in traindf:    
#         drop_column = ['Age','Fare','Name','Ticket']    
drop_column = ['Age','Fare','Name','Ticket']
dataset.drop(drop_column, axis=1, inplace = True)
traindf = dataset
drop_column = ['PassengerId']
traindf.drop(drop_column, axis=1, inplace = True)
traindf = pd.get_dummies(traindf, columns = ["Sex","Title","Age_bin","Embarked","Fare_bin"], prefix=["Sex","Title","Age_type","Em_type","Fare_type"])

sns.heatmap(traindf.corr(),annot=True,cmap='RdYlGn',linewidths=0.2) #data.corr()-->correlation 
matrixfig=plt.gcf()
matrixfig.set_size_inches(20,12)
plt.show()


from sklearn.model_selection import train_test_split #for split the data
from sklearn.metrics import accuracy_score  #for accuracy_score
from sklearn.model_selection import KFold #for K-fold cross validation
from sklearn.model_selection import cross_val_score #score evaluation
from sklearn.model_selection import cross_val_predict #prediction
from sklearn.metrics import confusion_matrix #for confusion matrix
all_features = traindf.drop("Survived",axis=1)
Targeted_feature = traindf["Survived"]
X_train,X_test,y_train,y_test = train_test_split(all_features,Targeted_feature,test_size=0.3,random_state=42)
# X_train.shape,X_test.shape,y_train.shape,y_test.shape
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
# X_train, X_test, y_train, y_test = train_test_split(x, y, test_size = 0.3)
model = RandomForestClassifier(criterion='gini', n_estimators=700, min_samples_split=10,min_samples_leaf=1, max_features='auto',oob_score=True,random_state=1,n_jobs=-1)
model.fit(X_train,y_train)
prediction_rm=model.predict(X_test)
print('--------------The Accuracy of the model----------------------------')
print('The accuracy of the Random Forest Classifier is', round(accuracy_score(prediction_rm,y_test)*100,2))
kfold = KFold(n_splits=10, random_state=22) # k=10, split the data into 10 equal partsresult_rm=cross_val_score(model,all_features,Targeted_feature,cv=10,scoring='accuracy')print('The cross validated score for Random Forest Classifier is:',round(result_rm.mean()*100,2))y_pred = cross_val_predict(model,all_features,Targeted_feature,cv=10)sns.heatmap(confusion_matrix(Targeted_feature,y_pred),annot=True,fmt='3.0f',cmap="summer")
plt.title('Confusion_matrix', y=1.05, size=15)

model = RandomForestClassifier(criterion='gini',n_estimators=700, min_samples_split=10,min_samples_leaf=1,max_features='auto',oob_score=True, random_state=1,n_jobs=-1)
# Random Forest Classifier Parameters tunning 
model = RandomForestClassifier()
n_estim=range(100,1000,100)

## Search grid for optimal parameters
param_grid = {"n_estimators" :n_estim}
model_rf = GridSearchCV(model,param_grid = param_grid, cv=5, scoring="accuracy", n_jobs= 4, verbose = 1)
model_rf.fit(X_train,y_train)
# Best scoreprint(model_rf.best_score_)

#best estimatormodel_rf.best_estimator_