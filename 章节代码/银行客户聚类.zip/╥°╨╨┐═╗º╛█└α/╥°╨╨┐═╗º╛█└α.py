# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 06:36:37 2019

@author: admin
"""

import pandas as pd
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist
import numpy as np
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore")
df = pd.read_csv("select-data.csv")

data = []
for i in range(0, len(df["EstimatedSalary"])):
    mid = []
    mid.append(df["Geography"][i])
    mid.append(df["Gender"][i])
    mid.append(df["EB"][i])
    mid.append(df["Age"][i])
    mid.append(df["EstimatedSalary"][i])
    mid.append(df["NumOfProducts"][i])
    mid.append(df["CreditScore"][i])
    mid.append(df["Tenure"][i])
    mid.append(df["HasCrCard"][i])
    data.append(mid)
data = np.array(data)
print(data)

# k means determine k
distortions = []
K = range(1, 15)
for k in K:
    kmeanModel = KMeans(n_clusters=k).fit(data)
    kmeanModel.fit(data)
    distortions.append(sum(np.min(cdist(data, kmeanModel.cluster_centers_, 'euclidean'), axis=1)) / data.shape[0])

 
# Plot the elbow
plt.plot(K, distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()
    
my_kmeans=KMeans(10).fit(data)
my_kmeans.fit(data)
y_means=my_kmeans.predict(data)
    
def print_kmcluster(k):
    for i in range(k):
        print('聚类',i)
        ls=[]
        for index,value in enumerate(y_means):
            if i==value:
                ls.append(index)
        print(np.mean(df["Geography"][ls]),np.mean(df["Gender"][ls]),np.mean(df["EB"][ls]),np.mean(df["Age"][ls]),np.mean(df["EstimatedSalary"][ls]),np.mean(df["NumOfProducts"][ls]),np.mean(df["CreditScore"][ls]),np.mean(df["Tenure"][ls]),np.mean(df["HasCrCard"][ls]))
        print(df.loc[ls,["Geography","Gender","EB","Age","EstimatedSalary","NumOfProducts","CreditScore","Tenure","HasCrCard"]])
            
       

print_kmcluster(10)


