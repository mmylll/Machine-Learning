# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 22:37:20 2020

@author: admin
"""

#用Python对Excel的20个常用操作

#xcel读取本地数据
import pandas as pd
import numpy as np
import matplotlib.pyplot as mp

df=pd.read_csv("select-data.csv")

randdata=pd.DataFrame(np.random.rand(10,2))
print(randdata)

#将当前工作表格保存
randdata.to_csv("随机数据.xlsx")

#对数据框进行条件筛选
print(df[df["CreditScore"]>0.7])

del df["EB"]
print(df)

#数据排序
df.sort_values("EstimatedSalary",ascending=False,inplace=True)
print(df)

#空值处理
print(df.isnull().sum())
df = df.fillna(axis=1,method='ffill')

#可视化
df["CreditScore"].hist()




