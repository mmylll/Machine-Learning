import pandas as pd
from apyori import apriori
import pyfpgrowth


def loadData():
    # 加载数据
    data = pd.read_excel('超市销售关联.xlsx')
    inputList = data.values.tolist()
    # 将表格中的 T 和 F 转换为 商品名称，A——F为商品编号
    header = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K']
    itemList = []
    for item in inputList:
        cur = []
        for i in range(len(item)):
            if item[i] == 'T':
                cur.append(header[i])
        itemList.append(cur)
    return itemList


def apriori_method(data, min_support, min_confidence, min_lift, max_length):
    associate_rules = apriori(data, min_support=min_support,
                              min_confidence=min_confidence, min_lift=min_lift, max_length=max_length)

    for rule in associate_rules:
        print("频繁项集 %s，置信度 %f" % (rule.items, rule.support))
        for item in rule.ordered_statistics:
            print("%s -> %s, 置信度 %f 提升度 %f" %
                  (item.items_base, item.items_add, item.confidence, item.lift))
        print()

def fpgrowth_method(data, min_support, min_confidence):
    # 频繁项集
    patterns = pyfpgrowth.find_frequent_patterns(data, min_support)

    # 规则
    rules = pyfpgrowth.generate_association_rules(patterns, min_confidence)
    print(rules)
    for i in rules:
        print("%s -> %s 置信度 %f" % (i, rules[i][0], rules[i][1]))


if __name__ == "__main__":
    data = loadData()

    min_support = 0.1       # 最小支持度
    min_confidence = 0.5    # 最小置信度
    min_lift = 0.0          # 最小提升度
    max_length = 3          # 最长关系长度
    print('Apriori得到的关联规则')
   # apriori_method(data, min_support, min_confidence, min_lift, max_length)
    print('FP-growth树得到的关联规则')
    fpgrowth_method(data, min_support, min_confidence)
